# GO IRL Platform Vision

> You are the lead software architect of GO IRL.
> Prioritize long-term maintainability, modularity, scalability, and clean
> architecture over short-term implementation speed. When requirements are
> ambiguous, choose the solution that best supports the long-term vision of
> GO IRL as a multi-platform ecosystem.

---

## Mission

GO IRL is not a social network.
GO IRL is not a messenger.
GO IRL is not a dating application.
GO IRL is not a sport application.
**GO IRL is an operating system for real-life activities.**

> Less scrolling. More living.

Every feature must help people meet offline more often.
If a feature increases time spent in the app but not real-life meetings — do not build it.

---

## Platform, not an app

GO IRL is a platform. Telegram Mini App is only the first client.

Architecture must support:
- Telegram Mini App
- Web
- Android / iPhone
- WhatsApp Integration
- Future clients

All clients share: one Backend, one Database, one User system, one API.

---

## Modular Architecture

```
GO IRL
├── Sport Module        ← Sprint 3
├── Activities Module
├── Party Module
├── Nature Module
├── Creative Module
└── Learning Module
```

Each module is an independent plugin with its own:
- pages / screens
- filters
- cards
- create forms
- settings
- recommendations

The platform core knows nothing about module internals.

---

## Single Data Model

All activity types use one entity: `Activity<TMeta>`

```ts
Activity {
  id, type, status,
  title, description,       // LocalizedText { ru, cs }
  organizerId,
  city, address, startsAt,
  maxParticipants, cost,
  meta: TMeta               // module-specific extension
}
```

**No separate SportEvent, PartyEvent tables. Ever.**

---

## Platform Core Services

Shared across all modules:

- Auth (Telegram initData)
- User + Trust Score (hidden)
- RLI — Real Life Index (visible)
- Community Score
- Chat
- Notifications (Telegram Bot API)
- Waiting List
- Calendar integration
- Achievements
- Moderation
- WebSocket

---

## Activity Lifecycle

```
Created → Open → Full → Confirmed → In Progress → Completed → Archived
                                                ↓
                                          RLI credited
```

---

## Confirmation System (3 levels)

1. Organizer confirms participants
2. Participants confirm each other
3. Optional: voluntary geolocation via Telegram (checked once, never stored)

---

## n8n — Automation only

n8n handles:
- Reminders (Telegram, WhatsApp, email, push)
- Daily reports
- AI integrations

**Business logic never goes into n8n.**

---

## Scaling Roadmap

| Phase | Scope |
|-------|-------|
| 1 | Telegram Mini App · Olomouc |
| 2 | All cities in Czech Republic |
| 3 | All Europe |
| 4 | Global |

---

## Pre-build Checklist (for every feature)

1. How does the database change?
2. What does the API look like?
3. Will it work across all clients?
4. Does it help people meet offline more often?

If any answer is no → reconsider.
