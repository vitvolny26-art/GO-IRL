# GO IRL — Documentation

Вся документация проекта живёт здесь. Переименована из корня репозитория.

| Файл | Содержание |
|------|------------|
| Book-I-Foundation.md | Why We Exist / Core Principles |
| Book-II-Architecture.md | Platform Architecture |
| Book-III-Database.md | Database Design |
| Book-IV-Modules.md | Modules Architecture |
| Book-V-PRD.md | Product Requirements Document |
| Book-VI-UX.md | UX & Interaction Guidelines |
| VISION.md | GO IRL Platform Vision (for Codex) |

> Документы из корня репозитория (`Chapter 1 Why We Exist`,
> `Book III ## 04 — Database Design` и др.) перемещены сюда и переименованы
> с расширением `.md` для корректного рендера на GitHub.
