import { theme } from "@go-irl/shared"
import { PHASE_1_CITY } from "@go-irl/shared"

export default function App() {
  return (
    <div
      style={{
        minHeight: "100vh",
        maxWidth: 430,
        margin: "0 auto",
        background: theme.bg,
        color: theme.text,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: 24,
        textAlign: "center",
        gap: 12,
      }}
    >
      <div style={{ fontSize: 32, fontWeight: 900 }}>
        <span style={{ background: theme.accent, color: "#000", padding: "2px 8px", borderRadius: 8 }}>GO</span>{" "}
        IRL
      </div>
      <div style={{ color: theme.textSub, fontSize: 14 }}>
        Sprint 0 — каркас собран ✅
      </div>
      <div style={{ color: theme.textMuted, fontSize: 12 }}>
        📍 {PHASE_1_CITY}
      </div>
    </div>
  )
}
