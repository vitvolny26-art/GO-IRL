# GO IRL

> Less scrolling. More living.
> An operating system for real-life activities.

Telegram Mini App платформа для офлайн-активностей. Фаза 1: Olomouc 🇨🇿

---

## Sprint 0 — Фундамент ✅

Каркас монорепо. Готов к первому `pnpm install`.

### Что реально существует

| Путь | Что это |
|------|---------|
| `backend/src/main.ts` | NestJS bootstrap |
| `backend/src/app.module.ts` | Root module |
| `backend/src/health/health.controller.ts` | `GET /health` → `{status:"ok"}` |
| `apps/telegram-miniapp/` | Vite + React, Telegram SDK подключён |
| `apps/web/` | Vite + React, заглушка для Phase 2 |
| `packages/types/` | `Activity<TMeta>`, `User`, `Participant` |
| `packages/contracts/` | API request/response типы |
| `packages/shared/` | Design tokens, константы |
| `infra/docker/` | Postgres compose + backend Dockerfile |
| `.github/workflows/ci.yml` | CI: install → lint → typecheck → build → test |
| `docs/VISION.md` | Полная архитектурная концепция платформы |

### Чего сознательно нет (по спринтам)

| Что | Когда |
|-----|-------|
| Prisma schema / миграции | Sprint 1 |
| Auth (Telegram initData) | Sprint 2 |
| ActivityService, бизнес-логика | Sprint 2 |
| Sport Module UI (фид, карточки) | Sprint 3 |
| Matching-алгоритм | Sprint 4 |
| Продакшн деплой | Sprint 5 |

---

## Структура

```
GO-IRL/
├── backend/                     NestJS API
│   ├── src/
│   │   ├── main.ts
│   │   ├── app.module.ts
│   │   └── health/health.controller.ts
│   ├── package.json
│   ├── tsconfig.json
│   └── nest-cli.json
│
├── apps/
│   ├── telegram-miniapp/        Primary client (Telegram)
│   └── web/                     Future web client
│
├── packages/
│   ├── types/                   Activity<TMeta>, User — shared model
│   ├── contracts/               API contracts (Sport, Auth)
│   └── shared/                  Design tokens, i18n constants
│
├── infra/
│   └── docker/
│       ├── docker-compose.yml   Postgres local dev
│       └── Dockerfile.backend
│
├── docs/                        Documentation (Books I–VI + Vision)
│
├── .github/workflows/ci.yml
├── package.json                 root (turbo scripts)
├── pnpm-workspace.yaml
├── turbo.json
├── tsconfig.base.json
└── CHECKLIST.md                 Пошаговая верификация сборки
```

---

## Быстрый старт

### Требования
- Node.js ≥ 20
- pnpm ≥ 9 (`corepack enable`)
- Docker (для Postgres, нужен с Sprint 1)

### Установка

```bash
git clone https://github.com/vitvolny26-art/GO-IRL.git
cd GO-IRL
pnpm install
# Закоммить pnpm-lock.yaml сразу после установки:
git add pnpm-lock.yaml
git commit -m "chore: add pnpm lockfile"
```

### Проверка

```bash
pnpm build       # собирает все пакеты через turbo
pnpm typecheck   # проверка типов
pnpm lint        # lint
```

### Разработка

```bash
# Backend → http://localhost:3000/health
pnpm --filter @go-irl/backend dev

# Telegram Mini App → http://localhost:5173
pnpm --filter @go-irl/telegram-miniapp dev
```

### Postgres (с Sprint 1)

```bash
cd infra/docker && docker compose up -d
```

---

## Архитектурные принципы

1. **Одна Activity.** Все типы (Sport, Party, Nature...) — один generic `Activity<TMeta>`. Никаких отдельных таблиц на модуль.
2. **Модули — плагины.** Ядро не знает деталей модуля.
3. **Один backend, много клиентов.** Все клиенты через одни `contracts`.
4. **Перед любой фичей — 4 вопроса** (см. `docs/VISION.md`).
5. **Сначала проверь, потом делай.** Показывать дерево файлов (`find . -type f`) перед любым рефакторингом.

---

## Правило работы с AI-агентами

Перед тем как описывать или менять файл — открыть и убедиться, что он существует.
Не доверять отчётам без реального `find` / `cat` вывода.

---

## Roadmap

- [x] Sprint 0 — Монорепо, CI, Docker, `/health` endpoint
- [ ] Sprint 1 — Prisma schema + PostgreSQL
- [ ] Sprint 2 — Auth (Telegram initData), Activity CRUD, Sport API
- [ ] Sprint 3 — Telegram Mini App: Sport module UI
- [ ] Sprint 4 — Matching: автоподбор игроков, приглашения
- [ ] Sprint 5 — Продакшн: деплой, бот, мониторинг
