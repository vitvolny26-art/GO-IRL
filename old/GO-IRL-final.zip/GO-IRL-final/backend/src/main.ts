import { NestFactory } from "@nestjs/core"
import { AppModule } from "./app.module"

async function bootstrap() {
  const app = await NestFactory.create(AppModule)
  app.enableCors()

  const port = process.env.PORT ?? 3000
  await app.listen(port)
  console.log(`GO IRL backend running on port ${port}`)
}

bootstrap()
