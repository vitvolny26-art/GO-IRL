# Sprint 0 — Verification Checklist

Цель: пройти этот список локально, по порядку. Каждый пункт — реальная
команда с реальным результатом. Никаких "по логике должно работать".

## 1. Окружение

```bash
node --version     # должно быть >= 20
corepack enable     # включает pnpm из packageManager в package.json
pnpm --version      # должно быть >= 9
```

## 2. Установка

```bash
pnpm install
```

**Ожидаемый результат:** появляется `pnpm-lock.yaml` в корне репозитория.

➡️ **Если установка прошла — закоммить `pnpm-lock.yaml` сразу:**
```bash
git add pnpm-lock.yaml
git commit -m "chore: add pnpm lock file"
```

После этого верни `.github/workflows/ci.yml` к строгому режиму:
```yaml
- name: Install dependencies
  run: pnpm install --frozen-lockfile
```

## 3. Typecheck (самый быстрый способ найти проблемы)

```bash
pnpm typecheck
```

Если падает — записывай **точный текст ошибки и файл**. Не пересказывай
своими словами, копируй вывод терминала целиком.

## 4. Build

```bash
pnpm build
```

Порядок сборки управляется turbo: `packages/types` → `packages/contracts`,
`packages/shared` → `backend`, `apps/*`.

Если какой-то пакет падает — выше по списку зависимостей искать причину
бессмысленно, проблема в этом конкретном пакете.

## 5. Lint

```bash
pnpm lint
```

На Sprint 0 eslint конфиги ещё не созданы для большинства пакетов —
ожидаемо может ругаться на их отсутствие. Это не баг, это следующий шаг
(добавление `.eslintrc` будет в Sprint 1 вместе с Prisma).

## 6. Запуск backend

```bash
pnpm --filter @go-irl/backend dev
```

Открой `http://localhost:3000/health` — должен вернуться:
```json
{ "status": "ok", "service": "go-irl-backend" }
```

## 7. Запуск Telegram Mini App

```bash
pnpm --filter @go-irl/telegram-miniapp dev
```

Открой `http://localhost:5173` — должна отрисоваться чёрная страница
с надписью "GO IRL" и "Sprint 0 — каркас собран ✅".

## 8. Docker (после того как lock-файл закоммичен)

```bash
cd infra/docker
docker build -f Dockerfile.backend -t goirl-backend ../..
```

**Важно:** `Dockerfile.backend` использует `pnpm install --frozen-lockfile`
точно так же как CI — это означает, что Docker-сборка упадёт по той же
причине, что и CI, пока `pnpm-lock.yaml` не закоммичен. Это один и тот же
блокер в двух местах, не две разные проблемы.

После коммита lock-файла, протестируй контейнер:
```bash
docker run -p 3000:3000 goirl-backend
curl http://localhost:3000/health
```

---

## Журнал аудита

| # | Пункт | Статус | Примечание |
|---|-------|--------|------------|
| 1 | pnpm-lock.yaml отсутствует | 🔴 подтверждено | требует локального `pnpm install`, см. шаг 2 |
| 2 | class-validator / swagger в backend | ✅ ложная тревога | в коде нет таких импортов — добавлять нечего |
| 3 | Prisma schema отсутствует | ✅ ожидаемо | Prisma — задача Sprint 1, в Sprint 0 её не должно быть |
| 4 | exports/types/main в пакетах | 🟢 исправлено | добавлено поле `exports` в types/shared/contracts |
| 5 | Turbo pipeline покрывает все таски | ✅ подтверждено | build/dev/lint/test/typecheck/clean есть везде |
| 6 | Dockerfile.backend | 🟢 исправлено | теперь использует `turbo prune`, было: копирование всего `node_modules` + тот же frozen-lockfile блокер |
| 7 | CI таски существуют во всех пакетах | ✅ подтверждено | те же скрипты, что и #5 |
| 8 | tsconfig extends/include/outDir | 🟡 частично | backend использует CommonJS+declaration:true от base — рабочая комбинация, но не выровнена с project references (осознанно не добавлены, см. ниже) |
| 9 | Импорты workspace соответствуют экспортам | ✅ подтверждено | grep проверил каждый импортируемый символ |
| 10 | Полный прогон pnpm install/typecheck/build/lint | ⏳ ждёт локального запуска | невозможно проверить без реального Node.js окружения |

**По поводу TypeScript project references (часть пункта #8):**
сознательно не добавлены. Текущая схема — пакеты экспортируют `.ts` напрямую
(`"main": "./src/index.ts"`), и turbo строит граф сборки через
`dependsOn: ["^build"]` + `workspace:*`, а не через `tsc --build` references.
Смешивание этих двух подходов добавляет сложности без выгоды на этом этапе.
Если в Sprint 1+ понадобится инкрементальная компиляция через `tsc --build` —
тогда добавим `references` отдельным шагом, с собственной проверкой.


Скопируй сюда (или в чат) ровно то, что вывел терминал на каждом шаге,
где что-то пошло не так. Формат:

```
Шаг: pnpm build
Команда: pnpm build
Ошибка:
<вставить точный текст>
```

Без точного текста ошибки невозможно отличить реальную проблему конфигурации
от версии pnpm/node/turbo, отличающейся в твоём окружении.
